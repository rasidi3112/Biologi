import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Play, BookOpen } from 'lucide-react';
import { ExperimentSidebar } from '@/components/experiment-sidebar';
import { SimulationViewport } from '@/components/simulation-viewport';
import { TemperatureChart } from '@/components/temperature-chart';
import { ObservationForm } from '@/components/observation-form';
import { TeacherDashboard } from '@/components/teacher-dashboard';
import { useSimulation } from '@/hooks/use-simulation';
import { getStudentData } from '@/lib/student-storage';
import { ObservationData } from '@/types/simulation';

export default function Home() {
  const [selectedExperiment, setSelectedExperiment] = useState('greenhouse-effect');
  const [currentMode, setCurrentMode] = useState<'student' | 'teacher'>('student');
  
  const {
    state: simulationState,
    startSimulation,
    pauseSimulation,
    resetSimulation,
    updateSettings
  } = useSimulation(selectedExperiment);

  useEffect(() => {
    const studentData = getStudentData();
    setCurrentMode(studentData.mode);
    setSelectedExperiment(studentData.currentExperiment || 'greenhouse-effect');
  }, []);

  const handleSaveData = () => {
    // Data is automatically saved via useSimulation hook
    console.log('Data saved to localStorage');
  };

  const handleGenerateWorksheet = (observationData: ObservationData) => {
    // Create worksheet content
    const worksheetContent = {
      experimentType: selectedExperiment,
      studentName: getStudentData().name,
      observation: observationData,
      simulationData: simulationState.data,
      timestamp: new Date().toISOString()
    };

    // Create and download as JSON (in a real app, this would generate a PDF)
    const blob = new Blob([JSON.stringify(worksheetContent, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lembar-kerja-${selectedExperiment}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <section className="mb-12">
          <div className="relative h-80 rounded-2xl overflow-hidden bg-gradient-to-r from-earth-blue via-primary to-secondary">
            <div className="absolute inset-0 bg-black bg-opacity-20"></div>
            <div className="relative z-10 h-full flex items-center justify-center text-center text-white p-8">
              <div className="max-w-4xl">
                <h1 className="text-4xl md:text-6xl font-bold mb-4">
                  Virtual Lab 3D
                  <span className="text-accent"> Pemanasan Global</span>
                </h1>
                <p className="text-xl md:text-2xl mb-8 text-blue-100">
                  Pelajari penyebab, dampak, dan solusi pemanasan global melalui eksperimen virtual yang interaktif
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    size="lg"
                    className="bg-accent hover:bg-orange-600 text-white px-8 py-3 font-semibold transform hover:scale-105 transition-all"
                    onClick={startSimulation}
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Mulai Simulasi
                  </Button>
                  <Button 
                    size="lg"
                    variant="outline"
                    className="bg-white/20 hover:bg-white/30 text-white border-white/30 backdrop-blur-sm px-8 py-3 font-semibold"
                  >
                    <BookOpen className="w-5 h-5 mr-2" />
                    Panduan Praktikum
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Sidebar - Experiment List */}
          <div className="lg:col-span-1">
            <ExperimentSidebar
              selectedExperiment={selectedExperiment}
              onExperimentSelect={setSelectedExperiment}
            />
          </div>

          {/* Center - 3D Simulation Viewport */}
          <div className="lg:col-span-2 space-y-6">
            <SimulationViewport
              experimentType={selectedExperiment}
              simulationState={simulationState}
              onStartSimulation={startSimulation}
              onPauseSimulation={pauseSimulation}
              onResetSimulation={resetSimulation}
              onUpdateSettings={updateSettings}
              onSaveData={handleSaveData}
            />

            <TemperatureChart data={simulationState.data} />

            <ObservationForm
              experimentType={selectedExperiment}
              onGenerateWorksheet={handleGenerateWorksheet}
            />
          </div>
        </div>

        {/* Teacher Dashboard */}
        <TeacherDashboard isVisible={currentMode === 'teacher'} />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">🌍</span>
                </div>
                <span className="font-bold text-gray-900">Virtual Lab 3D</span>
              </div>
              <p className="text-gray-600 text-sm">
                Aplikasi pembelajaran interaktif untuk memahami pemanasan global melalui simulasi virtual.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Tim Pengembang</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <div>Enges Sukma Pratiwi</div>
                <div>Asyh Cahyunita Putri H.A</div>
                <div>Aisha Khairina Wahid</div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Kontak</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <div>Universitas Mataram</div>
                <div>Fakultas Keguruan dan Ilmu Pendidikan (FKIP)</div>
                <div className="text-primary">virtuallab3d@unram.ac.id</div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-200 mt-8 pt-6 text-center text-sm text-gray-600">
            <p>&copy; 2024 Virtual Lab 3D - FKIP Universitas Mataram. Dibuat untuk pembelajaran Biologi.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
