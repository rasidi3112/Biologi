import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Globe, GraduationCap, Users } from 'lucide-react';
import { getStudentData, setMode } from '@/lib/student-storage';

export function Navigation() {
  const [location] = useLocation();
  const [currentMode, setCurrentMode] = useState<'student' | 'teacher'>(
    getStudentData().mode
  );

  const handleModeSwitch = (mode: 'student' | 'teacher') => {
    setCurrentMode(mode);
    setMode(mode);
  };

  const studentData = getStudentData();

  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                <Globe className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Virtual Lab 3D</h1>
                <p className="text-xs text-gray-600">Pemanasan Global</p>
              </div>
            </Link>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <Button 
                variant={location === '/' ? 'default' : 'ghost'}
                className="font-medium"
              >
                Beranda
              </Button>
            </Link>
            <Button variant="ghost" className="text-gray-600 hover:text-primary">
              Praktikum
            </Button>
            <Button variant="ghost" className="text-gray-600 hover:text-primary">
              Simulasi 3D
            </Button>
            <Button variant="ghost" className="text-gray-600 hover:text-primary">
              Lembar Kerja
            </Button>
          </nav>

          <div className="flex items-center space-x-4">
            {/* Mode Toggle */}
            <div className="hidden sm:flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
              <Button
                variant={currentMode === 'student' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleModeSwitch('student')}
                className="text-sm"
              >
                <GraduationCap className="w-4 h-4 mr-1" />
                Siswa
              </Button>
              <Button
                variant={currentMode === 'teacher' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleModeSwitch('teacher')}
                className="text-sm"
              >
                <Users className="w-4 h-4 mr-1" />
                Guru
              </Button>
            </div>
            
            {/* User Profile */}
            <div className="flex items-center space-x-2">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-gradient-to-br from-accent to-warm-orange text-white text-sm font-medium">
                  {studentData.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <span className="hidden sm:block text-sm font-medium">
                {studentData.name}
              </span>
              <Badge variant="outline" className="hidden sm:block">
                {currentMode === 'student' ? 'Siswa' : 'Guru'}
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
