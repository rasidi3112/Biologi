import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  CheckCircle, 
  Clock, 
  Plus, 
  Download,
  Presentation 
} from 'lucide-react';

interface TeacherDashboardProps {
  isVisible: boolean;
}

export function TeacherDashboard({ isVisible }: TeacherDashboardProps) {
  const [quizTitle, setQuizTitle] = useState('');
  const [quizDescription, setQuizDescription] = useState('');

  const handleCreateQuiz = () => {
    if (!quizTitle || !quizDescription) return;
    
    // TODO: Implement quiz creation
    console.log('Creating quiz:', { title: quizTitle, description: quizDescription });
    setQuizTitle('');
    setQuizDescription('');
  };

  const mockStudentResults = [
    { id: 1, name: 'Aisha Khairina Wahid', experiment: 'Efek Rumah Kaca', status: 'Selesai' },
    { id: 2, name: 'Asyh Cahyunita Putri H.A', experiment: 'Percobaan CO₂', status: 'Sedang Berlangsung' },
    { id: 3, name: 'Ahmad Rizki', experiment: 'Tutupan Lahan', status: 'Selesai' },
    { id: 4, name: 'Sarah Melinda', experiment: 'Asamifikasi Laut', status: 'Selesai' }
  ];

  if (!isVisible) return null;

  return (
    <section className="mt-12">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Presentation className="text-primary mr-3" />
            Dashboard Guru
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-blue-50">
              <CardContent className="p-6 text-center">
                <Users className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-blue-600">24</div>
                <div className="text-sm text-gray-600">Total Siswa</div>
              </CardContent>
            </Card>
            
            <Card className="bg-green-50">
              <CardContent className="p-6 text-center">
                <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-green-600">18</div>
                <div className="text-sm text-gray-600">Tugas Selesai</div>
              </CardContent>
            </Card>
            
            <Card className="bg-yellow-50">
              <CardContent className="p-6 text-center">
                <Clock className="w-8 h-8 text-yellow-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-yellow-600">23</div>
                <div className="text-sm text-gray-600">Rata-rata Waktu (menit)</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Create Quiz */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Buat Kuis Baru</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Judul Kuis"
                  value={quizTitle}
                  onChange={(e) => setQuizTitle(e.target.value)}
                />
                <Textarea
                  placeholder="Deskripsi kuis..."
                  className="h-24"
                  value={quizDescription}
                  onChange={(e) => setQuizDescription(e.target.value)}
                />
                <Button onClick={handleCreateQuiz} className="w-full">
                  <Plus className="w-4 h-4 mr-2" />
                  Tambah Kuis
                </Button>
              </CardContent>
            </Card>
            
            {/* Student Results */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Hasil Siswa</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {mockStudentResults.map((result) => (
                    <div 
                      key={result.id}
                      className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="font-medium">{result.name}</div>
                        <div className="text-sm text-gray-600 flex items-center space-x-2">
                          <span>{result.experiment}</span>
                          <Badge 
                            variant={result.status === 'Selesai' ? 'default' : 'secondary'}
                            className="text-xs"
                          >
                            {result.status}
                          </Badge>
                        </div>
                      </div>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 pt-4 border-t">
                  <Button variant="outline" className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Unduh Semua Hasil
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
