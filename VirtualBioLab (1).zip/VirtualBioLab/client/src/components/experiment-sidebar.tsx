import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  FlaskRound, 
  Cloud, 
  Thermometer, 
  Droplets, 
  ExternalLink,
  Home,
  Timer
} from 'lucide-react';
import { ExperimentType } from '@/types/simulation';
import { setCurrentExperiment } from '@/lib/student-storage';

const experiments: ExperimentType[] = [
  {
    id: 1,
    name: "Efek Rumah Kaca Sederhana",
    type: "greenhouse-effect",
    description: "Simulasi 3D dengan dua toples kaca dan termometer",
    duration: 15,
    icon: "home",
    category: "Interaktif"
  },
  {
    id: 2,
    name: "Percobaan Karbon Dioksida",
    type: "co2-experiment", 
    description: "Visualisasi produksi dan efek gas CO₂",
    duration: 20,
    icon: "cloud",
    category: "3D Model"
  },
  {
    id: 3,
    name: "Pengaruh Tutupan Lahan",
    type: "land-cover",
    description: "Perbandingan suhu berbagai permukaan",
    duration: 25,
    icon: "thermometer",
    category: "Komparasi"
  },
  {
    id: 4,
    name: "Asamifikasi Laut",
    type: "ocean-acidification",
    description: "Simulasi perubahan pH air laut",
    duration: 18,
    icon: "droplets",
    category: "pH Indicator"
  }
];

const getIcon = (iconName: string) => {
  const icons = {
    home: Home,
    cloud: Cloud,
    thermometer: Thermometer,
    droplets: Droplets
  };
  return icons[iconName as keyof typeof icons] || FlaskRound;
};

const getCategoryColor = (category: string) => {
  const colors = {
    "Interaktif": "bg-green-100 text-green-700",
    "3D Model": "bg-blue-100 text-blue-700",
    "Komparasi": "bg-yellow-100 text-yellow-700",
    "pH Indicator": "bg-purple-100 text-purple-700"
  };
  return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-700";
};

interface ExperimentSidebarProps {
  selectedExperiment: string;
  onExperimentSelect: (experimentType: string) => void;
}

export function ExperimentSidebar({ 
  selectedExperiment, 
  onExperimentSelect 
}: ExperimentSidebarProps) {
  const handleExperimentClick = (experimentType: string) => {
    setCurrentExperiment(experimentType);
    onExperimentSelect(experimentType);
  };

  return (
    <Card className="sticky top-24">
      <CardContent className="p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
          <FlaskRound className="text-primary mr-3" />
          Daftar Praktikum
        </h2>
        
        <div className="space-y-4">
          {experiments.map((experiment) => {
            const IconComponent = getIcon(experiment.icon);
            const isSelected = selectedExperiment === experiment.type;
            
            return (
              <div
                key={experiment.id}
                className={`p-4 border rounded-lg cursor-pointer transition-all group ${
                  isSelected 
                    ? 'border-primary bg-blue-50 shadow-md' 
                    : 'border-gray-200 hover:border-primary hover:shadow-md'
                }`}
                onClick={() => handleExperimentClick(experiment.type)}
              >
                <div className="flex items-start space-x-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                    isSelected 
                      ? 'bg-primary text-white' 
                      : 'bg-green-100 group-hover:bg-primary group-hover:text-white'
                  }`}>
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className={`font-semibold transition-colors ${
                      isSelected 
                        ? 'text-primary' 
                        : 'text-gray-900 group-hover:text-primary'
                    }`}>
                      {experiment.name}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {experiment.description}
                    </p>
                    <div className="flex items-center mt-2 space-x-2">
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${getCategoryColor(experiment.category)}`}
                      >
                        {experiment.category}
                      </Badge>
                      <div className="flex items-center text-xs text-gray-500">
                        <Timer className="w-3 h-3 mr-1" />
                        {experiment.duration} menit
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* External Links */}
        <div className="mt-8 pt-6 border-t border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-4">Simulasi External</h3>
          <div className="space-y-2">
            <Button 
              variant="link" 
              className="p-0 h-auto text-sm text-primary hover:text-blue-700 justify-start"
              asChild
            >
              <a 
                href="https://phet.colorado.edu/en/simulations/greenhouse-effect" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                PhET Climate Change
              </a>
            </Button>
            <Button 
              variant="link" 
              className="p-0 h-auto text-sm text-primary hover:text-blue-700 justify-start"
              asChild
            >
              <a 
                href="https://climatekids.nasa.gov/climate-change-meaning/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                NASA Climate Kids
              </a>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
