import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ClipboardList, Save, FileDown } from 'lucide-react';
import { ObservationData } from '@/types/simulation';
import { updateObservation, getStudentData } from '@/lib/student-storage';

interface ObservationFormProps {
  experimentType: string;
  onGenerateWorksheet: (data: ObservationData) => void;
}

export function ObservationForm({ experimentType, onGenerateWorksheet }: ObservationFormProps) {
  const { toast } = useToast();
  const [observation, setObservation] = useState<ObservationData>({
    hypothesis: '',
    results: '',
    conclusion: '',
    questions: ''
  });

  // Load existing observation data
  useEffect(() => {
    const studentData = getStudentData();
    const existingObservation = studentData.observations[experimentType];
    if (existingObservation) {
      setObservation(existingObservation);
    }
  }, [experimentType]);

  const handleSave = () => {
    updateObservation(experimentType, observation);
    toast({
      title: "Catatan Tersimpan",
      description: "Catatan pengamatan berhasil disimpan.",
    });
  };

  const handleGenerateWorksheet = () => {
    if (!observation.hypothesis || !observation.results) {
      toast({
        title: "Data Tidak Lengkap",
        description: "Mohon isi hipotesis dan hasil pengamatan terlebih dahulu.",
        variant: "destructive"
      });
      return;
    }
    
    onGenerateWorksheet(observation);
    toast({
      title: "Lembar Kerja Dibuat",
      description: "Lembar kerja praktikum berhasil dibuat dan akan diunduh.",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <ClipboardList className="text-primary mr-3" />
          Catatan Pengamatan
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="hypothesis">Hipotesis Awal</Label>
            <Textarea
              id="hypothesis"
              placeholder="Tuliskan hipotesis Anda tentang efek rumah kaca..."
              className="h-24"
              value={observation.hypothesis}
              onChange={(e) => setObservation(prev => ({ ...prev, hypothesis: e.target.value }))}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="results">Hasil Pengamatan</Label>
            <Textarea
              id="results"
              placeholder="Catat hasil pengamatan dari simulasi..."
              className="h-24"
              value={observation.results}
              onChange={(e) => setObservation(prev => ({ ...prev, results: e.target.value }))}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="conclusion">Kesimpulan</Label>
            <Textarea
              id="conclusion"
              placeholder="Tulis kesimpulan berdasarkan hasil simulasi..."
              className="h-24"
              value={observation.conclusion}
              onChange={(e) => setObservation(prev => ({ ...prev, conclusion: e.target.value }))}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="questions">Pertanyaan Lanjutan</Label>
            <Textarea
              id="questions"
              placeholder="Pertanyaan yang muncul setelah praktikum..."
              className="h-24"
              value={observation.questions}
              onChange={(e) => setObservation(prev => ({ ...prev, questions: e.target.value }))}
            />
          </div>
        </div>
        
        <div className="mt-6 flex flex-wrap gap-3">
          <Button onClick={handleSave} className="flex items-center">
            <Save className="w-4 h-4 mr-2" />
            Simpan Catatan
          </Button>
          <Button 
            onClick={handleGenerateWorksheet} 
            variant="outline"
            className="flex items-center"
          >
            <FileDown className="w-4 h-4 mr-2" />
            Unduh Lembar Kerja
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
