import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { 
  Box, 
  RotateCcw, 
  Maximize, 
  Play, 
  Pause, 
  Square, 
  Save,
  Sun,
  Thermometer
} from 'lucide-react';
import { ThreeScene } from './three-scene';
import { SimulationState } from '@/types/simulation';

interface SimulationViewportProps {
  experimentType: string;
  simulationState: SimulationState;
  onStartSimulation: () => void;
  onPauseSimulation: () => void;
  onResetSimulation: () => void;
  onUpdateSettings: (updates: Partial<SimulationState>) => void;
  onSaveData: () => void;
}

export function SimulationViewport({
  experimentType,
  simulationState,
  onStartSimulation,
  onPauseSimulation,
  onResetSimulation,
  onUpdateSettings,
  onSaveData
}: SimulationViewportProps) {
  
  const getExperimentTitle = (type: string) => {
    const titles = {
      'greenhouse-effect': 'Efek Rumah Kaca',
      'co2-experiment': 'Percobaan Karbon Dioksida',
      'land-cover': 'Pengaruh Tutupan Lahan',
      'ocean-acidification': 'Asamifikasi Laut'
    };
    return titles[type as keyof typeof titles] || 'Simulasi 3D';
  };

  const handleObjectClick = (object: any) => {
    // Handle 3D object interactions
    console.log('Clicked object:', object);
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-gray-100">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Box className="text-primary mr-3" />
            Simulasi 3D: {getExperimentTitle(experimentType)}
          </div>
          <div className="flex items-center space-x-2">
            <Button size="sm" variant="outline" onClick={onResetSimulation}>
              <RotateCcw className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="outline">
              <Maximize className="w-4 h-4" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-0">
        {/* 3D Viewport */}
        <div className="relative">
          <ThreeScene
            experimentType={experimentType}
            simulationState={simulationState}
            onObjectClick={handleObjectClick}
          />
          
          {/* 3D Controls Overlay */}
          <div className="absolute top-4 left-4">
            <Card className="bg-white/90 backdrop-blur-sm">
              <CardContent className="p-3">
                <h4 className="font-semibold text-sm text-gray-900 mb-2">Kontrol 3D</h4>
                <div className="space-y-1 text-xs text-gray-600">
                  <div>🖱️ Drag: Rotasi view</div>
                  <div>🔍 Scroll: Zoom in/out</div>
                  <div>👆 Click: Info detail</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Temperature Display */}
          <div className="absolute top-4 right-4">
            <Card className="bg-white/90 backdrop-blur-sm">
              <CardContent className="p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <Thermometer className="w-4 h-4 text-red-500" />
                  <span className="text-sm font-semibold">Suhu Real-time</span>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {simulationState.temperature.toFixed(1)}°C
                  </div>
                  <div className="text-xs text-gray-600">
                    Tanpa Tutup: {(simulationState.temperature - 2).toFixed(1)}°C
                  </div>
                  <div className="text-xs text-gray-600">
                    Dengan Tutup: {simulationState.temperature.toFixed(1)}°C
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Simulation Controls */}
        <div className="p-6 border-t border-gray-100 bg-gray-50">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {/* Light Intensity Control */}
            <Card>
              <CardContent className="p-4">
                <Label className="flex items-center text-sm font-medium text-gray-700 mb-3">
                  <Sun className="w-4 h-4 text-yellow-500 mr-2" />
                  Intensitas Cahaya
                </Label>
                <Slider
                  value={[simulationState.lightIntensity]}
                  onValueChange={([value]) => onUpdateSettings({ lightIntensity: value })}
                  max={100}
                  step={5}
                  className="mb-2"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>Rendah</span>
                  <Badge variant="secondary">{simulationState.lightIntensity}%</Badge>
                  <span>Tinggi</span>
                </div>
              </CardContent>
            </Card>

            {/* Glass Cover Toggle */}
            <Card>
              <CardContent className="p-4">
                <Label className="flex items-center text-sm font-medium text-gray-700 mb-3">
                  <div className="w-4 h-4 bg-blue-500 rounded mr-2" />
                  Tutup Kaca
                </Label>
                <RadioGroup
                  value={simulationState.glassCover}
                  onValueChange={(value: 'none' | 'covered') => onUpdateSettings({ glassCover: value })}
                  className="space-y-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="none" id="none" />
                    <Label htmlFor="none" className="text-sm">Tanpa Tutup</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="covered" id="covered" />
                    <Label htmlFor="covered" className="text-sm">Dengan Tutup</Label>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Time Control */}
            <Card>
              <CardContent className="p-4">
                <Label className="flex items-center text-sm font-medium text-gray-700 mb-3">
                  <div className="w-4 h-4 bg-purple-500 rounded mr-2" />
                  Kecepatan Waktu
                </Label>
                <Select 
                  value={simulationState.timeSpeed.toString()}
                  onValueChange={(value) => onUpdateSettings({ timeSpeed: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Normal (1x)</SelectItem>
                    <SelectItem value="2">Cepat (2x)</SelectItem>
                    <SelectItem value="5">Sangat Cepat (5x)</SelectItem>
                    <SelectItem value="10">Ultra Cepat (10x)</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3">
            <Button 
              onClick={simulationState.isRunning ? onPauseSimulation : onStartSimulation}
              className="flex items-center"
            >
              {simulationState.isRunning ? (
                <>
                  <Pause className="w-4 h-4 mr-2" />
                  Jeda
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Mulai Simulasi
                </>
              )}
            </Button>
            <Button variant="outline" onClick={onResetSimulation} className="flex items-center">
              <Square className="w-4 h-4 mr-2" />
              Reset
            </Button>
            <Button variant="outline" onClick={onSaveData} className="flex items-center">
              <Save className="w-4 h-4 mr-2" />
              Simpan Data
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
