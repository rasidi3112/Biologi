import { useMemo } from 'react';
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';
import { TemperatureData } from '@/types/simulation';

interface TemperatureChartProps {
  data: TemperatureData[];
}

export function TemperatureChart({ data }: TemperatureChartProps) {
  const chartData = useMemo(() => {
    return data.map((point, index) => ({
      time: `${index * 5} min`,
      "Tanpa Tutup": parseFloat(point.withoutCover.toFixed(1)),
      "Dengan Tutup": parseFloat(point.withCover.toFixed(1))
    }));
  }, [data]);

  const stats = useMemo(() => {
    if (data.length === 0) {
      return {
        avgTemp: 24.3,
        maxTemp: 28.7,
        minTemp: 19.2,
        tempDiff: 4.6
      };
    }

    const withCoverTemps = data.map(d => d.withCover);
    const withoutCoverTemps = data.map(d => d.withoutCover);
    
    const avgWithCover = withCoverTemps.reduce((a, b) => a + b, 0) / withCoverTemps.length;
    const avgWithoutCover = withoutCoverTemps.reduce((a, b) => a + b, 0) / withoutCoverTemps.length;
    
    return {
      avgTemp: parseFloat(((avgWithCover + avgWithoutCover) / 2).toFixed(1)),
      maxTemp: parseFloat(Math.max(...withCoverTemps, ...withoutCoverTemps).toFixed(1)),
      minTemp: parseFloat(Math.min(...withCoverTemps, ...withoutCoverTemps).toFixed(1)),
      tempDiff: parseFloat((avgWithCover - avgWithoutCover).toFixed(1))
    };
  }, [data]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingUp className="text-primary mr-3" />
          Grafik Perubahan Suhu
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12 }}
                axisLine={{ stroke: '#e5e7eb' }}
              />
              <YAxis 
                domain={['dataMin - 2', 'dataMax + 2']}
                tick={{ fontSize: 12 }}
                axisLine={{ stroke: '#e5e7eb' }}
                label={{ value: 'Suhu (°C)', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="Tanpa Tutup" 
                stroke="hsl(158, 64%, 52%)" 
                strokeWidth={2}
                dot={{ fill: "hsl(158, 64%, 52%)", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: "hsl(158, 64%, 52%)", strokeWidth: 2 }}
              />
              <Line 
                type="monotone" 
                dataKey="Dengan Tutup" 
                stroke="hsl(0, 72%, 51%)" 
                strokeWidth={2}
                dot={{ fill: "hsl(0, 72%, 51%)", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: "hsl(0, 72%, 51%)", strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="bg-blue-50 rounded-lg p-3">
            <div className="text-sm text-gray-600">Suhu Rata-rata</div>
            <div className="text-xl font-bold text-blue-600">
              {stats.avgTemp}°C
            </div>
          </div>
          <div className="bg-red-50 rounded-lg p-3">
            <div className="text-sm text-gray-600">Suhu Maksimum</div>
            <div className="text-xl font-bold text-red-600">
              {stats.maxTemp}°C
            </div>
          </div>
          <div className="bg-green-50 rounded-lg p-3">
            <div className="text-sm text-gray-600">Suhu Minimum</div>
            <div className="text-xl font-bold text-green-600">
              {stats.minTemp}°C
            </div>
          </div>
          <div className="bg-purple-50 rounded-lg p-3">
            <div className="text-sm text-gray-600">Selisih</div>
            <div className="text-xl font-bold text-purple-600">
              +{stats.tempDiff}°C
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
