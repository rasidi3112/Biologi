import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { createGreenhouseScene, updateThermometer, createCO2Scene } from '@/lib/three-utils';
import { SimulationState } from '@/types/simulation';

interface ThreeSceneProps {
  experimentType: string;
  simulationState: SimulationState;
  onObjectClick?: (object: THREE.Object3D) => void;
}

export function ThreeScene({ experimentType, simulationState, onObjectClick }: ThreeSceneProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    jars?: THREE.Group[];
    thermometers?: THREE.Group[];
    bottles?: THREE.Group[];
    light?: THREE.DirectionalLight;
    gas?: THREE.Points;
  } | null>(null);
  const animationIdRef = useRef<number>();

  useEffect(() => {
    if (!mountRef.current) return;

    // Initialize scene based on experiment type
    let sceneData;
    if (experimentType === 'greenhouse-effect') {
      sceneData = createGreenhouseScene();
    } else if (experimentType === 'co2-experiment') {
      sceneData = createCO2Scene();
    } else {
      // Default to greenhouse effect
      sceneData = createGreenhouseScene();
    }

    sceneRef.current = sceneData;
    const { renderer, camera, scene } = sceneData;

    // Set up renderer
    const container = mountRef.current;
    const rect = container.getBoundingClientRect();
    renderer.setSize(rect.width, rect.height);
    renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(renderer.domElement);

    // Mouse controls
    let mouseX = 0;
    let mouseY = 0;
    let isMouseDown = false;

    const handleMouseMove = (event: MouseEvent) => {
      if (!isMouseDown) return;
      
      const deltaX = event.clientX - mouseX;
      const deltaY = event.clientY - mouseY;
      
      // Rotate camera around scene
      const spherical = new THREE.Spherical();
      spherical.setFromVector3(camera.position);
      spherical.theta -= deltaX * 0.01;
      spherical.phi += deltaY * 0.01;
      spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, spherical.phi));
      
      camera.position.setFromSpherical(spherical);
      camera.lookAt(0, 0, 0);
      
      mouseX = event.clientX;
      mouseY = event.clientY;
    };

    const handleMouseDown = (event: MouseEvent) => {
      isMouseDown = true;
      mouseX = event.clientX;
      mouseY = event.clientY;
    };

    const handleMouseUp = () => {
      isMouseDown = false;
    };

    const handleWheel = (event: WheelEvent) => {
      event.preventDefault();
      const scale = event.deltaY > 0 ? 1.1 : 0.9;
      camera.position.multiplyScalar(scale);
      camera.position.clampLength(5, 20);
    };

    const handleClick = (event: MouseEvent) => {
      if (!onObjectClick) return;
      
      const rect = container.getBoundingClientRect();
      const mouse = new THREE.Vector2(
        ((event.clientX - rect.left) / rect.width) * 2 - 1,
        -((event.clientY - rect.top) / rect.height) * 2 + 1
      );
      
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(mouse, camera);
      
      const intersects = raycaster.intersectObjects(scene.children, true);
      if (intersects.length > 0) {
        onObjectClick(intersects[0].object);
      }
    };

    renderer.domElement.addEventListener('mousemove', handleMouseMove);
    renderer.domElement.addEventListener('mousedown', handleMouseDown);
    renderer.domElement.addEventListener('mouseup', handleMouseUp);
    renderer.domElement.addEventListener('wheel', handleWheel);
    renderer.domElement.addEventListener('click', handleClick);

    // Animation loop
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      // Update scene based on simulation state
      if (experimentType === 'greenhouse-effect' && sceneData.thermometers) {
        sceneData.thermometers.forEach((thermometer, index) => {
          const temp = index === 0 
            ? simulationState.temperature - 2 // Without cover
            : simulationState.temperature; // With cover
          updateThermometer(thermometer, temp);
        });
      }

      if (sceneData.light) {
        sceneData.light.intensity = simulationState.lightIntensity / 100;
      }

      if (experimentType === 'co2-experiment' && sceneData.gas) {
        // Animate CO2 particles
        const positions = sceneData.gas.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < positions.length; i += 3) {
          positions[i] += 0.01; // Move particles up
          if (positions[i] > 8) {
            positions[i] = 0; // Reset to bottom
          }
        }
        sceneData.gas.geometry.attributes.position.needsUpdate = true;
      }

      renderer.render(scene, camera);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      if (!mountRef.current) return;
      const rect = mountRef.current.getBoundingClientRect();
      camera.aspect = rect.width / rect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(rect.width, rect.height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      renderer.domElement.removeEventListener('mousemove', handleMouseMove);
      renderer.domElement.removeEventListener('mousedown', handleMouseDown);
      renderer.domElement.removeEventListener('mouseup', handleMouseUp);
      renderer.domElement.removeEventListener('wheel', handleWheel);
      renderer.domElement.removeEventListener('click', handleClick);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [experimentType, onObjectClick]);

  // Update scene when simulation state changes
  useEffect(() => {
    if (!sceneRef.current) return;
    
    // Scene updates are handled in the animation loop
    // This effect ensures the scene responds to state changes
  }, [simulationState]);

  return (
    <div 
      ref={mountRef} 
      className="w-full h-96 bg-gradient-to-b from-sky-200 to-green-200 relative"
      style={{ cursor: 'grab' }}
    />
  );
}
