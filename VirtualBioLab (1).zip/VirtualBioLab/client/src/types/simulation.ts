export interface SimulationState {
  lightIntensity: number;
  glassCover: 'none' | 'covered';
  timeSpeed: number;
  temperature: number;
  isRunning: boolean;
  data: TemperatureData[];
}

export interface TemperatureData {
  time: number;
  withCover: number;
  withoutCover: number;
}

export interface ObservationData {
  hypothesis: string;
  results: string;
  conclusion: string;
  questions: string;
}

export interface ExperimentType {
  id: number;
  name: string;
  type: string;
  description: string;
  duration: number;
  icon: string;
  category: string;
}

export interface StudentData {
  id: number;
  name: string;
  currentExperiment: string;
  observations: Record<string, ObservationData>;
  results: Record<string, any>;
  mode: 'student' | 'teacher';
}
