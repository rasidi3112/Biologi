import { StudentData, ObservationData } from "@/types/simulation";

const STORAGE_KEY = 'virtualLabStudentData';

export function getStudentData(): StudentData {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (error) {
      console.error('Failed to parse student data:', error);
    }
  }
  
  // Default student data
  const defaultData: StudentData = {
    id: 1,
    name: 'Enges Sukma',
    currentExperiment: 'greenhouse-effect',
    observations: {},
    results: {},
    mode: 'student'
  };
  
  saveStudentData(defaultData);
  return defaultData;
}

export function saveStudentData(data: StudentData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Failed to save student data:', error);
  }
}

export function updateObservation(experimentType: string, observation: ObservationData): void {
  const data = getStudentData();
  data.observations[experimentType] = observation;
  saveStudentData(data);
}

export function updateResults(experimentType: string, results: any): void {
  const data = getStudentData();
  data.results[experimentType] = results;
  saveStudentData(data);
}

export function setMode(mode: 'student' | 'teacher'): void {
  const data = getStudentData();
  data.mode = mode;
  saveStudentData(data);
}

export function getCurrentExperiment(): string {
  const data = getStudentData();
  return data.currentExperiment;
}

export function setCurrentExperiment(experimentType: string): void {
  const data = getStudentData();
  data.currentExperiment = experimentType;
  saveStudentData(data);
}
