import * as THREE from 'three';

export function createGreenhouseScene(): {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  jars: THREE.Group[];
  thermometers: THREE.Group[];
  light: THREE.DirectionalLight;
} {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87CEEB);

  const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
  camera.position.set(0, 5, 10);

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  // Lighting
  const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
  scene.add(ambientLight);

  const light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(0, 10, 5);
  light.castShadow = true;
  light.shadow.mapSize.width = 2048;
  light.shadow.mapSize.height = 2048;
  scene.add(light);

  // Ground
  const groundGeometry = new THREE.PlaneGeometry(20, 20);
  const groundMaterial = new THREE.MeshLambertMaterial({ color: 0x4CAF50 });
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  // Create glass jars
  const jars: THREE.Group[] = [];
  const thermometers: THREE.Group[] = [];

  for (let i = 0; i < 2; i++) {
    const jarGroup = new THREE.Group();
    
    // Jar base
    const baseGeometry = new THREE.CylinderGeometry(1.5, 1.5, 0.1, 32);
    const baseMaterial = new THREE.MeshLambertMaterial({ color: 0x8D6E63 });
    const base = new THREE.Mesh(baseGeometry, baseMaterial);
    base.position.y = 0.05;
    base.castShadow = true;
    jarGroup.add(base);

    // Glass cylinder
    const glassGeometry = new THREE.CylinderGeometry(1.4, 1.4, 3, 32);
    const glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.3,
      transmission: 0.9,
      roughness: 0.1
    });
    const glass = new THREE.Mesh(glassGeometry, glassMaterial);
    glass.position.y = 1.55;
    jarGroup.add(glass);

    // Glass top (only for covered jar)
    if (i === 1) {
      const topGeometry = new THREE.CylinderGeometry(1.4, 1.4, 0.1, 32);
      const top = new THREE.Mesh(topGeometry, glassMaterial);
      top.position.y = 3.05;
      jarGroup.add(top);
    }

    jarGroup.position.x = (i - 0.5) * 4;
    scene.add(jarGroup);
    jars.push(jarGroup);

    // Thermometer
    const thermometerGroup = createThermometer();
    thermometerGroup.position.set((i - 0.5) * 4, 1.5, 0);
    scene.add(thermometerGroup);
    thermometers.push(thermometerGroup);
  }

  return { scene, camera, renderer, jars, thermometers, light };
}

function createThermometer(): THREE.Group {
  const group = new THREE.Group();

  // Thermometer tube
  const tubeGeometry = new THREE.CylinderGeometry(0.05, 0.05, 2, 8);
  const tubeMaterial = new THREE.MeshLambertMaterial({ color: 0xC0C0C0 });
  const tube = new THREE.Mesh(tubeGeometry, tubeMaterial);
  group.add(tube);

  // Mercury/alcohol
  const mercuryGeometry = new THREE.CylinderGeometry(0.03, 0.03, 1, 8);
  const mercuryMaterial = new THREE.MeshLambertMaterial({ color: 0xFF0000 });
  const mercury = new THREE.Mesh(mercuryGeometry, mercuryMaterial);
  mercury.position.y = -0.5;
  mercury.name = 'mercury';
  group.add(mercury);

  // Bulb
  const bulbGeometry = new THREE.SphereGeometry(0.15, 16, 16);
  const bulb = new THREE.Mesh(bulbGeometry, mercuryMaterial);
  bulb.position.y = -1.2;
  group.add(bulb);

  return group;
}

export function updateThermometer(thermometer: THREE.Group, temperature: number): void {
  const mercury = thermometer.getObjectByName('mercury') as THREE.Mesh;
  if (mercury) {
    // Scale mercury height based on temperature (20-30°C range)
    const normalizedTemp = Math.max(0, Math.min(1, (temperature - 20) / 10));
    mercury.scale.y = 0.5 + normalizedTemp * 1.5;
    mercury.position.y = -0.5 + (normalizedTemp * 0.5);
  }
}

export function createCO2Scene(): {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  bottles: THREE.Group[];
  gas: THREE.Points;
} {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87CEEB);

  const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
  camera.position.set(0, 3, 8);

  const renderer = new THREE.WebGLRenderer({ antialias: true });

  // Lighting
  const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
  scene.add(ambientLight);

  const light = new THREE.DirectionalLight(0xffffff, 0.8);
  light.position.set(5, 5, 5);
  scene.add(light);

  // Create bottles
  const bottles: THREE.Group[] = [];
  
  for (let i = 0; i < 2; i++) {
    const bottleGroup = new THREE.Group();
    
    // Bottle body
    const bodyGeometry = new THREE.CylinderGeometry(0.8, 0.8, 3, 16);
    const bodyMaterial = new THREE.MeshLambertMaterial({ 
      color: 0x4CAF50,
      transparent: true,
      opacity: 0.7 
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    bottleGroup.add(body);

    // Bottle neck
    const neckGeometry = new THREE.CylinderGeometry(0.3, 0.3, 0.8, 16);
    const neck = new THREE.Mesh(neckGeometry, bodyMaterial);
    neck.position.y = 1.9;
    bottleGroup.add(neck);

    bottleGroup.position.x = (i - 0.5) * 3;
    scene.add(bottleGroup);
    bottles.push(bottleGroup);
  }

  // CO2 gas particles
  const gasGeometry = new THREE.BufferGeometry();
  const gasPositions = new Float32Array(300 * 3);
  
  for (let i = 0; i < 300; i++) {
    gasPositions[i * 3] = (Math.random() - 0.5) * 10;
    gasPositions[i * 3 + 1] = Math.random() * 5;
    gasPositions[i * 3 + 2] = (Math.random() - 0.5) * 10;
  }
  
  gasGeometry.setAttribute('position', new THREE.BufferAttribute(gasPositions, 3));
  
  const gasMaterial = new THREE.PointsMaterial({
    color: 0x666666,
    size: 0.1,
    transparent: true,
    opacity: 0.6
  });
  
  const gas = new THREE.Points(gasGeometry, gasMaterial);
  scene.add(gas);

  return { scene, camera, renderer, bottles, gas };
}
