import { useState, useCallback, useRef, useEffect } from 'react';
import { SimulationState, TemperatureData } from '@/types/simulation';
import { updateResults } from '@/lib/student-storage';

const initialState: SimulationState = {
  lightIntensity: 75,
  glassCover: 'covered',
  timeSpeed: 2,
  temperature: 24.5,
  isRunning: false,
  data: []
};

export function useSimulation(experimentType: string = 'greenhouse-effect') {
  const [state, setState] = useState<SimulationState>(initialState);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const timeRef = useRef(0);

  const updateTemperature = useCallback(() => {
    setState(prev => {
      const baseTemp = 22;
      const lightEffect = (prev.lightIntensity / 100) * 8;
      const coverEffect = prev.glassCover === 'covered' ? 4 : 0;
      const timeEffect = Math.sin(timeRef.current * 0.1) * 2;
      
      const withCover = baseTemp + lightEffect + coverEffect + timeEffect;
      const withoutCover = baseTemp + lightEffect + timeEffect;
      
      const newDataPoint: TemperatureData = {
        time: timeRef.current,
        withCover: withCover,
        withoutCover: withoutCover
      };

      const newData = [...prev.data.slice(-20), newDataPoint];
      
      // Save to localStorage
      updateResults(experimentType, {
        currentTemperature: prev.glassCover === 'covered' ? withCover : withoutCover,
        data: newData,
        settings: {
          lightIntensity: prev.lightIntensity,
          glassCover: prev.glassCover,
          timeSpeed: prev.timeSpeed
        }
      });

      return {
        ...prev,
        temperature: prev.glassCover === 'covered' ? withCover : withoutCover,
        data: newData
      };
    });
    
    timeRef.current += 1;
  }, [experimentType]);

  const startSimulation = useCallback(() => {
    if (intervalRef.current) return;
    
    setState(prev => ({ ...prev, isRunning: true }));
    intervalRef.current = setInterval(updateTemperature, 1000 / state.timeSpeed);
  }, [updateTemperature, state.timeSpeed]);

  const pauseSimulation = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setState(prev => ({ ...prev, isRunning: false }));
  }, []);

  const resetSimulation = useCallback(() => {
    pauseSimulation();
    timeRef.current = 0;
    setState(initialState);
  }, [pauseSimulation]);

  const updateSettings = useCallback((updates: Partial<SimulationState>) => {
    setState(prev => ({ ...prev, ...updates }));
    
    // Restart interval if time speed changed and simulation is running
    if (updates.timeSpeed && state.isRunning) {
      pauseSimulation();
      setTimeout(startSimulation, 100);
    }
  }, [state.isRunning, startSimulation, pauseSimulation]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return {
    state,
    startSimulation,
    pauseSimulation,
    resetSimulation,
    updateSettings
  };
}
