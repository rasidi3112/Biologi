# Virtual Lab 3D - Pemanasan Global

## Overview

This is an educational web application for learning about global warming through interactive 3D simulations. The application is built as a virtual laboratory for biology education, specifically designed for students at FKIP Universitas Mataram. It provides hands-on virtual experiments to understand climate change concepts including greenhouse effects, CO2 emissions, land cover impacts, and ocean acidification.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Bundler**: Vite for development and production builds
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom educational theme
- **3D Graphics**: Three.js for interactive 3D simulations
- **State Management**: React hooks with custom simulation hooks
- **Routing**: Wouter for lightweight client-side routing
- **Data Fetching**: TanStack Query (React Query) for server state

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints for experiments and student progress
- **Development Mode**: Vite middleware integration for hot reloading
- **Error Handling**: Centralized error middleware with structured responses

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema**: Defined in shared/schema.ts with Zod validation
- **Local Storage**: Browser localStorage for student session data
- **Session Management**: In-memory storage with fallback to database

## Key Components

### Database Schema
- **Users**: Student and teacher accounts with role-based access
- **Experiments**: Different types of climate experiments (greenhouse-effect, co2-experiment, etc.)
- **Student Progress**: Tracks simulation data, completion status, and scores
- **Worksheets**: Stores student observation forms and generated reports
- **Quizzes**: Teacher-created assessments with JSON-based questions

### 3D Simulation Engine
- **Greenhouse Effect**: Interactive jar experiments with thermometers
- **CO2 Visualization**: Particle systems for gas emission modeling
- **Temperature Tracking**: Real-time data collection and visualization
- **Interactive Controls**: Sliders, toggles, and parameter adjustment

### Educational Features
- **Observation Forms**: Structured data collection for scientific method
- **Temperature Charts**: Real-time graphing with Recharts
- **Worksheet Generation**: Downloadable reports in JSON format
- **Teacher Dashboard**: Student progress monitoring and quiz creation

## Data Flow

1. **Student Interaction**: Users select experiments from sidebar navigation
2. **Simulation Control**: Parameters adjusted through UI controls update 3D scene
3. **Data Collection**: Temperature and observation data stored locally and optionally synced to server
4. **Progress Tracking**: Completion status and scores saved to database
5. **Report Generation**: Observation forms combined with simulation data for worksheets

## External Dependencies

### Frontend Libraries
- **@radix-ui/**: Complete set of accessible UI primitives
- **three**: 3D graphics rendering and scene management
- **recharts**: Data visualization and charting
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight routing solution
- **class-variance-authority**: Type-safe component variants

### Backend Dependencies
- **drizzle-orm**: Type-safe database ORM with PostgreSQL
- **@neondatabase/serverless**: Serverless PostgreSQL adapter
- **express**: Web server framework
- **tsx**: TypeScript execution for development

### Development Tools
- **vite**: Fast build tool and development server
- **tailwindcss**: Utility-first CSS framework
- **typescript**: Type safety and enhanced development experience

## Deployment Strategy

### Development Environment
- **Local Setup**: Replit with PostgreSQL module enabled
- **Hot Reloading**: Vite middleware integrated with Express
- **Port Configuration**: Development server on port 5000
- **File Watching**: Automatic restart on server file changes

### Production Build
- **Client Build**: Vite builds React app to dist/public
- **Server Build**: esbuild bundles server code to dist/index.js
- **Static Assets**: Client assets served by Express in production
- **Environment Variables**: DATABASE_URL required for database connection

### Replit Configuration
- **Modules**: nodejs-20, web, postgresql-16
- **Run Command**: npm run dev for development
- **Deployment Target**: Autoscale with build and start commands
- **Port Mapping**: Internal port 5000 mapped to external port 80

## Changelog

```
Changelog:
- June 18, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```