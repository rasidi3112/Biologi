import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStudentProgressSchema, insertWorksheetSchema, insertQuizSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all experiments
  app.get("/api/experiments", async (req, res) => {
    try {
      const experiments = await storage.getExperiments();
      res.json(experiments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch experiments" });
    }
  });

  // Get specific experiment
  app.get("/api/experiments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const experiment = await storage.getExperiment(id);
      if (!experiment) {
        return res.status(404).json({ message: "Experiment not found" });
      }
      res.json(experiment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch experiment" });
    }
  });

  // Save student progress
  app.post("/api/student-progress", async (req, res) => {
    try {
      const validatedData = insertStudentProgressSchema.parse(req.body);
      const progress = await storage.saveStudentProgress(validatedData);
      res.json(progress);
    } catch (error) {
      res.status(400).json({ message: "Invalid progress data" });
    }
  });

  // Get student progress
  app.get("/api/student-progress/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const experimentId = req.query.experimentId ? parseInt(req.query.experimentId as string) : undefined;
      const progress = await storage.getStudentProgress(userId, experimentId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student progress" });
    }
  });

  // Update student progress
  app.put("/api/student-progress/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const progress = await storage.updateStudentProgress(id, updates);
      if (!progress) {
        return res.status(404).json({ message: "Progress not found" });
      }
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to update progress" });
    }
  });

  // Generate and download worksheet
  app.post("/api/worksheets", async (req, res) => {
    try {
      const validatedData = insertWorksheetSchema.parse(req.body);
      const worksheet = await storage.createWorksheet(validatedData);
      res.json(worksheet);
    } catch (error) {
      res.status(400).json({ message: "Invalid worksheet data" });
    }
  });

  // Get user worksheets
  app.get("/api/worksheets/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const worksheets = await storage.getWorksheets(userId);
      res.json(worksheets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch worksheets" });
    }
  });

  // Teacher routes
  app.get("/api/quizzes", async (req, res) => {
    try {
      const teacherId = req.query.teacherId ? parseInt(req.query.teacherId as string) : undefined;
      const quizzes = await storage.getQuizzes(teacherId);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quizzes" });
    }
  });

  app.post("/api/quizzes", async (req, res) => {
    try {
      const validatedData = insertQuizSchema.parse(req.body);
      const quiz = await storage.createQuiz(validatedData);
      res.json(quiz);
    } catch (error) {
      res.status(400).json({ message: "Invalid quiz data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
