import { 
  users, 
  experiments, 
  studentProgress, 
  worksheets, 
  quizzes,
  type User, 
  type InsertUser,
  type Experiment,
  type InsertExperiment,
  type StudentProgress,
  type InsertStudentProgress,
  type Worksheet,
  type InsertWorksheet,
  type Quiz,
  type InsertQuiz
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Experiments
  getExperiments(): Promise<Experiment[]>;
  getExperiment(id: number): Promise<Experiment | undefined>;
  createExperiment(experiment: InsertExperiment): Promise<Experiment>;
  
  // Student Progress
  getStudentProgress(userId: number, experimentId?: number): Promise<StudentProgress[]>;
  saveStudentProgress(progress: InsertStudentProgress): Promise<StudentProgress>;
  updateStudentProgress(id: number, progress: Partial<StudentProgress>): Promise<StudentProgress | undefined>;
  
  // Worksheets
  getWorksheets(userId: number): Promise<Worksheet[]>;
  createWorksheet(worksheet: InsertWorksheet): Promise<Worksheet>;
  
  // Quizzes
  getQuizzes(teacherId?: number): Promise<Quiz[]>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private experiments: Map<number, Experiment>;
  private studentProgressMap: Map<number, StudentProgress>;
  private worksheets: Map<number, Worksheet>;
  private quizzes: Map<number, Quiz>;
  private currentUserId: number;
  private currentExperimentId: number;
  private currentProgressId: number;
  private currentWorksheetId: number;
  private currentQuizId: number;

  constructor() {
    this.users = new Map();
    this.experiments = new Map();
    this.studentProgressMap = new Map();
    this.worksheets = new Map();
    this.quizzes = new Map();
    this.currentUserId = 1;
    this.currentExperimentId = 1;
    this.currentProgressId = 1;
    this.currentWorksheetId = 1;
    this.currentQuizId = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Create default experiments
    const defaultExperiments = [
      {
        name: "Efek Rumah Kaca Sederhana",
        type: "greenhouse-effect",
        description: "Simulasi 3D dengan dua toples kaca dan termometer",
        duration: 15,
        isActive: true
      },
      {
        name: "Percobaan Karbon Dioksida",
        type: "co2-experiment", 
        description: "Visualisasi produksi dan efek gas CO₂",
        duration: 20,
        isActive: true
      },
      {
        name: "Pengaruh Tutupan Lahan",
        type: "land-cover",
        description: "Perbandingan suhu berbagai permukaan",
        duration: 25,
        isActive: true
      },
      {
        name: "Asamifikasi Laut",
        type: "ocean-acidification",
        description: "Simulasi perubahan pH air laut",
        duration: 18,
        isActive: true
      }
    ];

    defaultExperiments.forEach(exp => {
      const id = this.currentExperimentId++;
      this.experiments.set(id, { ...exp, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getExperiments(): Promise<Experiment[]> {
    return Array.from(this.experiments.values()).filter(exp => exp.isActive);
  }

  async getExperiment(id: number): Promise<Experiment | undefined> {
    return this.experiments.get(id);
  }

  async createExperiment(insertExperiment: InsertExperiment): Promise<Experiment> {
    const id = this.currentExperimentId++;
    const experiment: Experiment = { ...insertExperiment, id };
    this.experiments.set(id, experiment);
    return experiment;
  }

  async getStudentProgress(userId: number, experimentId?: number): Promise<StudentProgress[]> {
    const allProgress = Array.from(this.studentProgressMap.values());
    return allProgress.filter(progress => 
      progress.userId === userId && 
      (experimentId ? progress.experimentId === experimentId : true)
    );
  }

  async saveStudentProgress(insertProgress: InsertStudentProgress): Promise<StudentProgress> {
    const id = this.currentProgressId++;
    const progress: StudentProgress = { 
      ...insertProgress, 
      id,
      createdAt: new Date()
    };
    this.studentProgressMap.set(id, progress);
    return progress;
  }

  async updateStudentProgress(id: number, updates: Partial<StudentProgress>): Promise<StudentProgress | undefined> {
    const existing = this.studentProgressMap.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.studentProgressMap.set(id, updated);
    return updated;
  }

  async getWorksheets(userId: number): Promise<Worksheet[]> {
    return Array.from(this.worksheets.values()).filter(worksheet => 
      worksheet.userId === userId
    );
  }

  async createWorksheet(insertWorksheet: InsertWorksheet): Promise<Worksheet> {
    const id = this.currentWorksheetId++;
    const worksheet: Worksheet = { 
      ...insertWorksheet, 
      id,
      createdAt: new Date()
    };
    this.worksheets.set(id, worksheet);
    return worksheet;
  }

  async getQuizzes(teacherId?: number): Promise<Quiz[]> {
    const allQuizzes = Array.from(this.quizzes.values());
    return allQuizzes.filter(quiz => 
      quiz.isActive && 
      (teacherId ? quiz.teacherId === teacherId : true)
    );
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const id = this.currentQuizId++;
    const quiz: Quiz = { 
      ...insertQuiz, 
      id,
      createdAt: new Date()
    };
    this.quizzes.set(id, quiz);
    return quiz;
  }
}

export const storage = new MemStorage();
